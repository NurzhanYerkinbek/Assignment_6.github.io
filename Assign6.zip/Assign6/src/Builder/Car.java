package Builder;

public class Car {
    private  int seats;
    private  String engine;
    private  String tripComputer;
    private  int gpsNavigator;

    public Car( int seats, String engine, String tripComputer,int gpsNavigator) {

        this.seats = seats;
        this.engine = engine;

        this.tripComputer = tripComputer;
        if (this.tripComputer != null) {
            this.tripComputer.getClass();
        }
        this.gpsNavigator = gpsNavigator;
    }




    public int getSeats() {
        return seats;
    }

    public String getEngine() {
        return engine;
    }


    public String getTripComputer() {
        return tripComputer;
    }

    public int getGpsNavigator() {
        return gpsNavigator;
    }
}
