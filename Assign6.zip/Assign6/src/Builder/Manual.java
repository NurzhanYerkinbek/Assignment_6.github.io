package Builder;

public class Manual {
    private int seats;
    private String engine;
    private String tripComputer;
    private int gpsNavigator;

    public Manual(int seats, String engine, String tripComputer, int gpsNavigator) {

        this.seats = seats;
        this.engine = engine;
        this.tripComputer = tripComputer;
        this.gpsNavigator = gpsNavigator;
    }


}