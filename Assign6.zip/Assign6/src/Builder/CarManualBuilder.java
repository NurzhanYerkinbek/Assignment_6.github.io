package Builder;

public class CarManualBuilder implements Builder{
    private int seats;
    private String engine;
    private String tripComputer;
    private int gpsNavigator;

    @Override
    public void reset() {

    }

    public void setSeats(int seats) {
        this.seats = seats;
    }


    public void setEngine(String engine) {
        this.engine = engine;
    }

    @Override
    public void setTripComputer() {

    }

    @Override
    public void setGPS() {

    }

    public void setTripComputer(String tripComputer) {
        this.tripComputer = tripComputer;
    }


    public void setGPSNavigator(int gpsNavigator) {
        this.gpsNavigator = gpsNavigator;
    }

    public Manual getResult() {
        return new Manual( seats, engine, tripComputer, gpsNavigator);
    }
}
