package Singleton;

 class  Application{
    public static void main(String[] args) {
        Database  foo  =  Database . getInstance();
        foo.query("select * from SimpliDB");
        }
    }
