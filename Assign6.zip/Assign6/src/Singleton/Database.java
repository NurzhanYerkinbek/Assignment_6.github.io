package Singleton;

import java.sql.*;

public class Database {
    private static Database instance;// need to add a private static field to the class containing a single object
    String connectionUrl = "jdbc:postgresql://localhost:5432/Nurzhan";
    Connection con = null;
    ResultSet rs = null;
    Statement stmt = null;
    private Database() { //Make the constructor of the class (default constructor) private (so that access to it is closed outside the class, then it will not be able to return new objects)
    }

    public static Database getInstance() { // Declare a static constructor method that will be used to get a singleton
        if (instance == null) {        //if the object hasn't been created yet
            instance = new Database();    //create a new object
        }
        return instance; //return the previously created object
    }


    public void query(String sql) {
        try
        {
            Class.forName("org.postgresql.Driver");// We load the driver's class file into memory at the runtime
            con = DriverManager.getConnection(connectionUrl,"postgres","Nurzhan2002"); //Establish the connection
            stmt = con.createStatement();// The object of statement is responsible to execute with the database
            rs = stmt.executeQuery(sql);//This method returns the object of ResultSet

            while(rs.next())// Processing the result
            {
                System.out.println(rs.getInt("user_id") + " " + rs.getString("user_name") + " " + rs.getString("user_surname") + " " + rs.getInt("user_gender"));
            }
        }

        catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }


        finally {
            try{ //Close connection - clean up the system resources
                rs.close();
                stmt.close();
                con.close();
            } catch (SQLException troubles) {
                troubles.printStackTrace();
            }
        }
    }



}