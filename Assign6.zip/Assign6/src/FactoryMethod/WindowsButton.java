package FactoryMethod;

public class WindowsButton implements Button {


    public void render() {
    }

    public void onClick() {
    }
}
