package FactoryMethod;


public class Application {
    private static Object dialog;
    public static void main(String[] args) {
        configure();
        runBusinessLogic();
    }
    static void configure() {
        Object dialog;
        if (System.getProperty("os.name").equals("Windows 10")) {
            dialog = new WindowsDialog();
        } else {
            dialog = new HtmlDialog();
        }
    }
    static void runBusinessLogic() {
        dialog.toString();
    }


}