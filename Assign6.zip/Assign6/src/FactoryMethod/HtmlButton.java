package FactoryMethod;

public class HtmlButton implements Button {

    public void render() {
        onClick();
    }

    public void onClick() {
    }
}
